#' Example price data for 5 speciees of fish caught in Lake Michigan and Lake Superior
#'
#' Data is arbitrary and was compiled to exemplify function
#'
#' @docType data
#'
#' @usage data(Price_Data)
#'
#'
#' @example
'Price_Data'
