#' Example catch data for 5 species of fish caught in Lake Michigan and Lake Superior
#'
#' Data is arbitrary and was compiled to exemplify function
#'
#' @docType data
#'
#' @usage data(Catch_Data)
#'
#'
#' @example
'Catch_Data'

