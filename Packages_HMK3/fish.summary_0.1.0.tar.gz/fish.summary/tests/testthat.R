library(testthat)
library(fish.summary)

test_check("fish.summary")
